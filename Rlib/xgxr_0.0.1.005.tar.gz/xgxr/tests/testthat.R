library(testthat)
library(xgx)

test_check("xgx")
