#' Calls the standard theme for xGx graphics
#'
#' @export

theme_xgx <- function() {
  xgx_theme()
}